DELETE FROM `grade_event`;
INSERT INTO `grade_event` VALUES ('2012-09-03','Q',NULL);
INSERT INTO `grade_event` VALUES ('2012-09-06','Q',NULL);
INSERT INTO `grade_event` VALUES ('2012-09-09','T',NULL);
INSERT INTO `grade_event` VALUES ('2012-09-16','Q',NULL);
INSERT INTO `grade_event` VALUES ('2012-09-23','Q',NULL);
INSERT INTO `grade_event` VALUES ('2012-10-01','T',NULL);
