$(function() {
	console.log('start');

	app.isDesktop = !_.isUndefined(window.btsync);
	app.config = {
		linkOnboarding: false
	};
	$('html').addClass(app.isDesktop ? 'isDesktop' : 'isWebui');

	function initLanguage(cb) {
		var initJsperanto = function(cb) {
			$.jsperanto.init(function() {
				if(app.lang)
					moment.lang(app.lang);
				cb && cb();
			},{
				dicoPath: 'locales',
				lang: app.lang,
				fallbackDictionary: window.langEn
			});
		};

		app.lang = app.utils.getURLParam('lang');
		if(app.lang)
			return initJsperanto(cb);

		utWebUI.getLang(function(r) {
			app.lang = r.value;
			if(app.lang && app.lang.length == 4) {
				// insert dash
				app.lang = app.lang.substr(0,2) + '-' + app.lang.substr(2,2);
			}
			if(app.lang)
				return initJsperanto(cb);

			utWebUI.getSystemInfo(function(r) {
				app.systemInfo = r.value;
				app.lang = r.value.language;
				initJsperanto(cb);
			});
		});
	};

	function checkBrowser(cb) {
		var found;
		for(var index in document.styleSheets){
			if (document.styleSheets[index].href && document.styleSheets[index].href.indexOf('css/style.css') > -1){
				found=true;
				break;
			}
		}

		if(!found) return;

		// attempt to replace with translated version
		if (!$('html').hasClass('svg')) {
			var template = app.templates["template-bad-browser"].call();
			$('#browser-container').html(template);
			return;
		}

		cb();
	};

	function initDatastore(cb) {
		app.store.init(cb);
	};

	var checkLicense = function(cb) {
		var licenseModel = new app.model.License;
		licenseModel.fetch({
			success: function() {
				if(licenseModel.get('licenseagreed')) {
					cb(true);
					return;
				}
				// show license agreement
				var licenseDialog = new app.view.License({
					successCallback: cb,
					model: licenseModel
				});
				licenseDialog.insert().open();
			}
		});
	};

	// yay for callbacks!
	initLanguage(function() {
		checkBrowser(function() {
			checkLicense(function() {
				initDatastore(function() {
					// initialize stuff that needs to exist no matter which page we're showing
					InitGlobal();
					// create main
					app.router = new app.Router
					Backbone.history.start();
				})
			});
		});
	});

	// detect browser properties
	app.browserInfo = {};
	(function() {
		if(!navigator.platform) return;
		if(navigator.platform.toLowerCase().match('mac')) return app.browserInfo.os = 'mac';
		if(navigator.platform.toLowerCase().match('win')) return app.browserInfo.os = 'win';
	})();

	app.scrollbarWidth = app.utils.getScrollBarWidth() || 0;
});

function coreEventListener(eventID, params) {
	try {
		params = JSON.parse(params);
	} catch(e) {};

	// TODO: consider moving this handler
	switch(eventID) {
		case SyncConstants.SYNC_CALLBACK_EVENT_LINK_CLICKED:
			var encodedLink = encodeURIComponent(params.value);
			utWebUI.request('action=parselink&link=' + encodedLink, function(r) {
				if(r.value.error)
					return window.btalert({title: $.t('invalidLink'), message: $.t('folderShareError' + r.value.error)});
				var options = {
					folderName: r.value.name,
					ex: r.value.expired,
					path: r.value.default_path,
					link: encodedLink,
					size: r.value.size
				};
				utWebUI.handleLinkRequest(options);
			}).fail(function(r) {
				return window.btalert({title: $.t('invalidLink'), message: $.t('folderShareError' + r.value.error)});
			});
			break;
		case SyncConstants.SYNC_CALLBACK_EVENT_NEW_ACCESS_REQUEST:
		case SyncConstants.SYNC_CALLBACK_EVENT_REQUEST_APPROVED:
		case SyncConstants.SYNC_CALLBACK_EVENT_REQUEST_REJECTED:
		case SyncConstants.SYNC_CALLBACK_EVENT_REQUEST_EXPIRED:
			app.approvals.fetch();
			break;
		case SyncConstants.SYNC_CALLBACK_EVENT_SHOW_FILE_DELETE_MESSAGE:
			window.btalert({
				title: $.t('deleterwtitle'),
				message: $.t('deleterwmessage1') + '<br><br>' + $.t('deleterwmessage2')
			});
			break;
		case SyncConstants.SYNC_CALLBACK_EVENT_SHOW_PREFERENCES:
			// open preferences dialog
			if ($('.modal:visible').length > 0) {
				var dialog = $('.modal:visible').data('modalClass');
				if(dialog)
					dialog.pulse();
				break;
			}

			var settingsDialog = new app.view.Settings;
			settingsDialog.insert().openScroll();
			break;
		case SyncConstants.SYNC_CALLBACK_EVENT_INSTALL_PATH:
			var onCollectionRequest = function(collection, response, options) {
				var results = collection.where({secret: params.value.secret});
				if (results.length > 0) {
					var folderModel = results[0];
					if (params.value.text || params.value.image) {
						var integrationDialog = new app.view.IntegrationDialog({
							model: folderModel,
							text: params.value.text,
							image: params.value.image
						});
						integrationDialog.insert().openScroll();
					}

					// Trigger tooltip
					if (params.value.folderadded) {
						folderModel.trigger('integrationTrigger');
					}
				}
			};

			getFolders(onCollectionRequest, onCollectionRequest);
			break;
		case SyncConstants.SYNC_CALLBACK_EVENT_RO_FILES_CHANGED:
			var folder = app.folders.get(params.value);
			if(!folder) {
				app.folders.fetch({
					success: function() {
						var folder = app.folders.get(params.value);
						if(!folder) return;
						btalert({
							title: $.t('changeROFilesTitle'),
							message: $.t('changeROFilesMessage'),
							folder: folder
						});
					}
				});
				return;
			}
			btalert({
				title: $.t('changeROFilesTitle'),
				message: $.t('changeROFilesMessage'),
				folder: folder
			});
			break;
		default:
			console.warn('core event', eventID, params);
			var ev = SyncConstants.callbacks[eventID + ''];
			if (!ev) {
				console.log('Unknown eventID: ' + ev);
			} else {
				$(window).trigger(ev, params);
			}
	}
};

function initMainPage(callback) {
	app.pausedModel = new app.model.Paused;
	app.pausedModel.fetch();

	app.notificationCenter = new app.view.NotificationCenter();
	app.notificationCenter.insert();

	main = new app.view.Main();
	$('body').append(main.render().el);
	console.log('onInit');

	Init();
	app.intialized = true;

	if(!app.isDesktop) return;
	btsync.setcallback({ functionname: "coreEventListener" });
}


// disable updater when page is in bg (doesn't seem to work when tab is active but window isn't)
var setUpdate;
(function() {
	app.updateInterval;
	var hidden = "hidden";

	// Standards:
	if (hidden in document)
			document.addEventListener("visibilitychange", onchange);
	else if ((hidden = "mozHidden") in document)
			document.addEventListener("mozvisibilitychange", onchange);
	else if ((hidden = "webkitHidden") in document)
			document.addEventListener("webkitvisibilitychange", onchange);
	else if ((hidden = "msHidden") in document)
			document.addEventListener("msvisibilitychange", onchange);
	// IE 9 and lower:
	else if ('onfocusin' in document)
			document.onfocusin = document.onfocusout = onchange;
	// All others:
	else
			window.onpageshow = window.onpagehide
					= window.onfocus = window.onblur = onchange;

	function onchange (evt) {
			var v = true, h = false,
					evtMap = {
							focus:v, focusin:v, pageshow:v, blur:h, focusout:h, pagehide:h
					};

			evt = evt || window.event;
			var isVisible;
			if (evt.type in evtMap)
					isVisible = evtMap[evt.type];
			else
					isVisible = this[hidden] ? false: true;

			isVisible ? setUpdate() : cancelUpdate();
	}

	setUpdate = function() {
		if(!app.folders) return;
		cancelUpdate();
		app.pauseUpdate = false;
		Update();

		if(!app.isDesktop) {
			UpdateApprovals();
		}
	};
	var cancelUpdate = function() {
		app.pauseUpdate = true;
		clearTimeout(app.updateInterval);
	}
})();

function InitGlobal() {
	app.settingsModel = new app.model.Settings;
	app.settingsModel.fetch();
}

function Init()
{
	// initialize singleton classes
	if(!app.isDesktop)
		app.settingsModel.on('change:devicename', function() {
			var devicename = app.settingsModel.get('devicename');
			$('head title').text('BitTorrent Sync Beta' + (devicename ? (' | ' + devicename) : ''));
		});

	app.approvals = new app.col.Approvals();
	app.notificationCenter.addGroup(new app.view.ApprovalNotificationGroup({
		collection: app.approvals
	}));

	app.pendingTasks = new Backbone.Collection;
	app.notificationCenter.addGroup(new app.view.PendingTaskNotificationGroup({
		collection: app.pendingTasks
	}));

	app.approvals.on('add', function(model, collection, options) {
		var secret = model.get('folder');
		var foldermodel = app.folders.where({ 'secret' : secret });
		if (foldermodel.length > 0) {
			foldermodel = foldermodel[0];

			var approvals = foldermodel.get('approval') || [];
			approvals.push(model);
			foldermodel.set({
				approval: approvals,
				approvaltrigger: Date.now()
			});
		}
	});

	app.approvals.on('remove', function(model, collection, options) {
		var secret = model.get('folder');
		var foldermodel = app.folders.where({ 'secret' : secret });
		if (foldermodel.length > 0) {
			foldermodel = foldermodel[0];

			var approvals = foldermodel.get('approval') || [];
			var index = approvals.indexOf(model);
			if (index > -1) {
				approvals.splice(index, 1);
				foldermodel.set({
					approval: approvals,
					approvaltrigger: Date.now()
				});
			}
		}
	});

	app.folders = new app.col.Folders();
	app.foldersView = new app.view.Folders();
	main.$('#folderContainer').append(app.foldersView.render().el);

	getFolders(function() {
		if(app.folders.length) {
			var firstRunTips = app.store.get('firstRunTips') || {};
			firstRunTips.addFolder = true;
			app.store.set('firstRunTips', firstRunTips);
			app.store.set('foldersAdded', true);
		}
	});

	// request approvals list when app is ready
	app.onAppReady(_.bind(app.approvals.fetch, app.approvals));

	app.userIdentity = new app.model.UserIdentity();
	app.userIdentity.fetch();

	app.addFolderView = new app.view.AddFolder();
	main.$el.append(app.addFolderView.render().el);
	app.updateSecretView = new app.view.UpdateSecretDialog();
	main.$el.append(app.updateSecretView.render().el);

	app.updateSecretSuccessView = new app.view.UpdateSecretSuccessDialog();
	main.$el.append(app.updateSecretSuccessView.render().el);

	utWebUI.getSystemInfo(function(f)
	{
		app.systemInfo = f.value;
		if (f.value.os == "win32")
			app.DELIMITER = "\\";
		else if (f.value.os == "linux" || f.value.os == "mac")
			app.DELIMITER = "/";

		// setup filetree
		app.folderSettings = new app.model.FolderSettings();
		app.folderSettings.fetch();

		setUpdate();

	});

	utWebUI.getVersion(function(f) {
		version = f.value;
		currentVersion = makeVersion(version);
		app.version = currentVersion.ver;
		checkVersion();
	});

	if(app.utils.getURLParam('debug')) return;
	new app.model.DebugMode().fetch({
		success: function(m) {

			if(m.get('value')) {
				if(app.isDesktop)
					try {
						btsync.debugtools = true;
					} catch(e) {}
				return;
			}

			// disable right click
			var preventRightClick = function(e) {
				if(e.which != 3) return;
				if($(e.target).closest('[data-toggle=context]').length) return;
				if($(e.target).closest('input,textarea').length) return;
				if($(e.target).closest('.text-selectable').length) return;
				return false;
			};
			$(document).on('mousedown', preventRightClick);
			$('body').on('contextmenu', preventRightClick);
		}
	});
}

function checkVersion()
{
	utWebUI.checkNewVersion(function(res)
	{
		if(!res.version)
			return;
		if(version < res.version.version)
		{
			app.pendingTasks.add({
				"url": res.version.url,
				"childView": app.view.UpdateTaskNotification
			});
		}
	});
}

function makeVersion(version)
{
	var v = { };

	v.major = (version & 0xFF000000) >> 24;
	v.minor = (version & 0x00FF0000)  >> 16;
	v.tiny = (version & 0x0000FFFF);
	v.ver = v.major + "." + v.minor + "." + v.tiny;

	return v;
}

function imagePrefetch() {
	// fetch css and scrape for image files
	$.get("css/style.css", function(response) {
		var matches = response.match(/url\(".*"\);/g)
		if(!matches) return;

		matches = _.map(matches,function(m) {
			m = m.slice(5, -3);
			if(m.substr(0,3) == '../')
				m = m.slice(3);
			return m;
		});
		app.prefetchedImages = [];
		_.each(matches, function(uri) {
			app.prefetchedImages.push(i = new Image());
			i.src = uri; // this should cause a GET of the image. That's all we need
		});
	});
}

imagePrefetch();

function Update()
{
	if(app.pauseUpdate) return;
	if(!app.folders) return;
	clearTimeout(app.updateInterval);
	getFolders(function() {
		app.updateInterval = setTimeout(Update, 1000);
	});
}

function UpdateApprovals()
{
	if(app.pauseUpdate) return;
	clearTimeout(app.approvalsUpdateInterval);
	getApprovals(function() {
		app.approvalsUpdateInterval = setTimeout(UpdateApprovals, 5000);
	});
}

function setSettings()
{
	var elems = ["listeningport", "dlrate", "ulrate", "portmapping"];
	var queryObj = {};
	for(var e = 0; e < elems.length; ++e)
	{
		var elem = $('#' + elems[e])[0];
		queryObj[elems[e]] = (elem.type == "checkbox" ? elem.checked : elem.value)
	}
	queryObj.devicename = $('#devicename').val();

	utWebUI.setSettings($.param(queryObj), function(c){ });
	var lang = $('#languagedrop').selectpicker('val');
	utWebUI.setLang(lang);

}

function img_create(src, alt, title) {
		var img= document.createElement('img');
		img.src= src;
		img.width = 20;
		img.height = 20;
		if (alt!=null) img.alt= alt;
		if (title!=null) img.title= title;
		return img;
}

function getFolders(success, error)
{
	app.folders.fetch({
		success: success,
		error: error
	});
}

function getApprovals(success, error)
{
	app.approvals.fetch({
		success: success,
		error: error
	});
}

window.btconfirm = function (message, callback, folder) {
	var opts;
	if(_.isObject(message))
		opts = message;
	else {
		opts = {
			message: message,
			callback: callback,
			folder: folder
		};
	}
	var dialog = new app.view.ConfirmDialog(opts);
	dialog.insert().open();
};

window.btalert = function(msg, folder) {
	window.btconfirm(msg, null, folder);
};

app.onAppReady = function(fn) {
	if(!_.isFunction(fn)) return;

	// check if app is already ready
	if(app.ready) return fn();

	// bind handler
	$(document).one('appReady', fn);
};

app.onAppReady(function() {
	console.log('app ready');
});

var timer;
var errorCount = 0;
var urlBase = "";
var guiBase = urlBase + "/gui/";
var proxyBase = urlBase + "/proxy";
var version = 0;

var utWebUI = {
	request: function(a, success)
	{
		var opts = success || {},
		    _this = this;

		if(_.isFunction(opts))
			opts = {
				success: success
			};

		var f = function() {
			var params = [];
			if(!app.isDesktop)
				params.push("token=" + _this.TOKEN);
			params.push(a);
			params.push("t=" + Date.now());
			var ajaxParams = _.extend({
				url: guiBase + "?" + params.join('&'),
				method: "get",
				async: true,
				dataType: "json"
			}, opts)
			return $.ajax(ajaxParams);
		}
		if(!this.TOKEN && !app.isDesktop)
		{
			return this.requestToken(f, true);
		}

		return f();

	},
	requestToken: function(c, b)
	{
		var a = this;
		$.ajax({
			type: "POST",
			url: guiBase + "token.html?t=" + Date.now(),
			async: false
		}).done(function( f )
		{
			var e = f.match(/>([^<]+)</);
			if(e) {
				a.TOKEN = e[e.length - 1]
				c();
			}
		});
	},
	getVersion: function(b, c)
	{
		this.request("action=version", b, c);
	},
	getFolderAttr: function(path, cb)
	{
		this.request("action=getattr&path=" + encodeURIComponent(path), cb);
	},
	addSyncFolder: function(n, s, f)
	{
		var name = encodeURIComponent(n);
		var secret = encodeURIComponent(s);

		this.request("action=addsyncfolder&path=" + name + (s ? ("&secret=" + secret) : ''), f);
	},
	addForceSyncFolder: function(n, s, f)
	{
		var name = encodeURIComponent(n);
		var secret = encodeURIComponent(s);

		this.request("action=addsyncfolder&path=" + name + (s ? ("&secret=" + secret) : '') + "&force=true", f);
	},
	addLink: function(link, path, cb) {
		utWebUI.request('action=addlink&link=' + link + '&path=' + encodeURIComponent(path), cb);
	},
	addForceLink: function(link, path, cb) {
		utWebUI.request('action=addlink&link=' + link + '&path=' + encodeURIComponent(path) + '&force=true', cb);
	},
	removeSyncFolder: function(s, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=removefolder&secret=" + secret, f);
	},
	generateSecret: function(f)
	{
		this.request("action=generatesecret", f);
	},
	getSettings: function(b)
	{
		this.request("action=settings", b);
	},
	setSettings: function(a, b)
	{
		this.request("action=setsettings" + a, b);
	},
	getSyncFolders: function(b)
	{
		this.request("action=getsyncfolders&discovery=1", b)
	},
	checkNewVersion: function(b)
	{
		this.request("action=checknewversion", b)
	},
	getFolderPreferences: function(s, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=folderpref&secret=" + secret, f);
	},
	setFolderPreferences: function(secret, a, b)
	{
		this.request("action=setfolderpref&secret=" + secret + '&' + a, b);
	},
	getHosts: function(s, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=knownhosts&secret=" + secret, f);
	},
	addHost: function(s, addr, port, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=addknownhost&secret=" + secret + "&addr=" + addr + "&port=" + port, f);
	},
	removeHost: function(s, index, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=removeknownhosts&secret=" + secret + "&index=" + index, f);
	},
	getLang: function(l)
	{
		this.request("action=userlang", l);
	},
	setLang: function(lang, l)
	{
		this.request("action=setuserlang&value=" + lang, l);
	},
	updateSecret: function(s, newsecret, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=updatesecret&secret=" + secret + "&newsecret=" + newsecret, f);
	},
	generateInvite: function(s, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=generateinvite&secret=" + secret, f);
	},
	generateROInvite: function(s, f)
	{
		var secret = encodeURIComponent(s);

		this.request("action=generateroinvite&secret=" + secret, f);
	},
	licenseAccept: function(username, password, f)
	{
		var str = 'action=accept';
		if(username)
			str = str + '&setcred=1&username=' + username + '&oldpwd=&newpwd=' + password;
		this.request(str, f);
	},
	licenseCancel: function(f)
	{
		this.request("action=cancel", f);
	},
	needLicense: function(f)
	{
		this.request("action=license", f);
	},
	addDirectory: function(f)
	{
		return this.request("action=adddir&dir=" + encodeURIComponent(f));
	},
	getUserName: function(f)
	{
			this.request("action=getusername", f);
	},
	setCredentials: function(name, oldPassword, newPassowrd, f)
	{
		 this.request("action=setcred&username=" + name + "&newpwd=" + newPassowrd + "&oldpwd=" + oldPassword, f);
	},
	hasPassword: function(f)
	{
		this.request("action=haspassword", f);
	},
	folderRoOverride: function(n, s, override, f)
	{
		var name = encodeURIComponent(n);
		var secret = encodeURIComponent(s);

		this.request("action=override&name=" + name + "&secret=" + secret + "&override=" + override, f);
	},
	getSyncLink: function(secret, params, f) {
		params = _.pick(params, 'readwrite', 'timelimit', 'clicklimit', 'askapproval', 'type');
		params.secret = secret;
		params = $.param(params);
		this.request("action=getsynclink&" + params, f);
	},
	getSystemInfo: function(f) {
		this.request('action=getsysteminfo', f);
	},
	checkForUpdate: function(f) {
		this.request('action=checkforupdate', f);
	},
	validateUserIdentity: function(cb) {
		var identity = new app.model.UserIdentity;
		identity.fetch({
			success: function() {
				if(identity.get('username')) {
					return cb(identity.get('username'));
				}

				var identityDialog = new app.view.UserIdentity({
					callback: cb
				});

				identityDialog.insert().open();
			}
		});
	},
	handleLinkRequest: function(options, force) {
		// Show message if another (nonconnect) modal is open
		if (!force && $('.modal-dialog:visible').length > 0 && $('#connect-dialog .modal-dialog:visible').length < 1) {
			app.pendingTasks.add(options);
			return;
		}

		var connectView = new app.view.Connect(options);
		connectView.insert().open();
	},
	linkAdded: function(link, added, reason) {
		try {
			return this.request('action=onlinkadded&link=' + link + '&added=' + added + '&reason=' + encodeURIComponent(reason));
		}catch(e) {}
	}
};

