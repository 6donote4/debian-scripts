app.view.HistoryEntryView = app.view.Base.extend({
	template: 'history-entry',
	tagName: 'tr'
});