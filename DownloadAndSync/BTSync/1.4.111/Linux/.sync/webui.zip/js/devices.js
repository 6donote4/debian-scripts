// Device Model
app.model.Device = Backbone.Model.extend({
	parse: function(m) {
		// fix weird encoding of mac device names
		m.name = app.utils.fixUnicode(m.name);
		m.lastseentime = m.lastseentime  || undefined;
		m.lastsynctime = m.lastsynctime  || undefined;
		m.totalfiles = (m.downfiles || 0) + (m.upfiles || 0);
		return m
	}
});


// Devices Collection
app.col.Devices = Backbone.Collection.extend({
	model: app.model.Device,
	comparator: function(m1, m2) {
		m1c = m1.get('isonline');
		m2c = m2.get('isonline');
		if(m1c && !m2c)
			return -1;
		if(m2c && !m1c)
			return 1;
		// return based on date
		return m2.get('lastseentime') - m1.get('lastseentime');
	}
});


// Device View
app.view.Device = app.view.Base.extend({
	template: 'connected-device',
	tagName: 'tr',
	className: 'device-row collapsed',
	attributes: {
		'data-toggle': 'collapse'
	},
	events: {
		'click a' : 'handleExternalLink',
		'click' : 'onClick'
	},
	initialize: function(opt) {
		this.listenTo(this.model, 'change', this.render);
		this.listenTo(this.model, 'remove', this.remove);
		app.view.Base.prototype.initialize.apply(this, arguments);
		this.listenTo(this.model, 'change:totalfiles', this.totalFilesChanged);
	},
	postRender: function() {
		if(!this.model.get('isonline')) {
			this.$el.addClass('notConnected');
		} else {
			this.$('#relay-icon').tooltip({
				delay: 500,
				container: '#peer-list-dialog'
			});
		}
	},
	totalFilesChanged: function() {
		if (this.model.get('isonline') && this.model.get('totalfiles')) {
			return;
		}
		this.hideFileQueue();
	},
	hideFileQueue: function() {
		var _this = this;
		this.$el.removeClass('expanded').addClass('collapsed');
		if(!this._fileQueueView) return;
		this._fileQueueView.hide(function() {
			_this._fileQueueView.remove();
			_this._fileQueueView = undefined;
		});
	},
	onClick: function(e) {
		if(!this.model.get('isonline') || !this.model.get('totalfiles')) {
	 		return false;
 		}

		if (this._fileQueueVisible) {
			this.hideFileQueue();
		}
		else {
			this._fileQueueView = new app.view.FileQueue({
				peer: this.model.id,
				secret: this.options.secret
			});
			this.$el.after(this._fileQueueView.render().el);
			this.listenTo(this._fileQueueView, 'loaded', function() {
				this.$el.removeClass('collapsed').addClass('expanded');
				this._fileQueueView.show();
			});
		}
		this._fileQueueVisible = !this._fileQueueVisible;
		return false;
	},
	remove: function() {
		this._fileQueueView && this._fileQueueView.remove();
		app.view.Base.prototype.remove.apply(this, arguments);
	}
});