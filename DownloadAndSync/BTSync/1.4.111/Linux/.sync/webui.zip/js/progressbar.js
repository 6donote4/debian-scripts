app.view.ProgressBar = app.view.Base.extend({
	template: 'progress-bar',
	className: 'radialProgressBarContainer',
	initialize: function() {
		app.view.Base.prototype.initialize.apply(this, arguments);
	},
	postRender: function() {
		this.svg = new SVGEl(this.$el.find( 'svg.progress-circle' )[0]);
		this.drawProgress();
		this.setColor();
	},
	drawProgress: function() {
		if(_.isUndefined(this.options.ratio)) return;
		this.svg.draw(this.options.ratio);
	},
	setColor: function() {
		if(!this.options.color) return;
		this.$el.find('svg.progress-circle path').attr('stroke', this.options.color);
	}
});


function SVGEl( el ) {
    this.el = el;
    // the path elements
    this.paths = $(this.el).find('path');
    // we will save both paths and its lengths in arrays
    this.pathsArr = new Array();
    this.lengthsArr = new Array();
    this._init();
}

SVGEl.prototype._init = function() {
    var self = this;
    this.paths.each( function( i, path ) {
        self.pathsArr[i] = path;
        path.style.strokeDasharray = self.lengthsArr[i] = path.getTotalLength();
    } );
    // undraw stroke
    this.draw(.5);
}

// val in [0,1] : 0 - no stroke is visible, 1 - stroke is visible
SVGEl.prototype.draw = function( val ) {
    for( var i = 0, len = this.pathsArr.length; i < len; ++i ){
        this.pathsArr[ i ].style.strokeDashoffset = this.lengthsArr[ i ] * ( 1 - val );
    }
}