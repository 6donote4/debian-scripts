app.view.EnterKey = app.view.BaseDialog.extend({
	template: 'enter-key-dialog',
	id: 'enter-key-dialog',
	events: {
		'click #enter-key-next': 'nextClicked',
		'shown.bs.modal': 'shownModal',
		'hidden.bs.modal': 'remove',
		'click #enter-key-error-text a': 'handleExternalLink'
	},
	_path: null,
	initialize: function() {
		_.bindAll(this, 'addFolderCallback', 'displayErrorMessage');
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
	},
	show: function() {
		this.$el.modal('show');
	},
	shownModal: function() {
		this.$('#enter-key-key').focus();
	},
	nextClicked: function() {
		var key = this.$el.find('#enter-key-key').val();

		if (!this.isLink(key) && this.validate(key)) {
			if (app.isDesktop) {
				this._path = btsync.showchoosefolderdialog();
				if (this._path) {
					var _this = this;
					utWebUI.addSyncFolder(
						_this._path,
						key,
						_this.addFolderCallback
					);
				}
			} else {
				this.close();
				this.options.addFolderView.show(key);
			}
		}
	},
	isLink: function(value) {
		var _this = this;
		if (value.indexOf("getsync") > 0) {      // if invitation link
			var encodedLink = encodeURIComponent(value);
			utWebUI.request('action=parselink&link=' + encodedLink, function(r) {
				if(r.value.error)
					return _this.displayErrorMessage($.t('folderShareError' + r.value.error));
				var options = {
					folderName: r.value.name,
					ex: r.value.expired,
					path: r.value.default_path,
					link: encodedLink,
					size: r.value.size
				};
				_this.linkOptions = options;
				_this.goToLinkFlow = true;
				_this.close();
			}).fail(function(r) {
				_this.displayErrorMessage($.t('folderShareError' + r.value.error));
			});;
			return true;
		}
		return false;
	},
	validate: function(key) {
		// TODO: determine proper validation
		if (!key || key.length < 32) {
			this.displayErrorMessage($.t('enterAKeyWarning'));
			return false;
		}
		this.$el.find('#enter-key-key').removeClass('warning');
		this.$el.find('#enter-key-error').addClass('invisible');
		return true;
	},
	displayErrorMessage: function(message) {
		this.$el.find('#enter-key-key').addClass('warning');
		this.$el.find('#enter-key-error-text').html(message).parent().removeClass('invisible');
	},
	remove: function() {
		if (this.goToLinkFlow) {
			utWebUI.handleLinkRequest(this.linkOptions);
		}
		app.view.BaseDialog.prototype.remove.apply(this, arguments);
	},
	handleFolderForceable: function(data) {
		var _this = this;
		var message = $.t('foldererror' + data.value.error, { folderName: data.value.path });
		btconfirm(message, function(success) {
			if (success) {
				utWebUI.addForceSyncFolder(data.value.path, data.value.secret, _this.addFolderCallback);
			}
		});
	},
	handleFolderUnrecoverable: function(data) {
		this.displayErrorMessage($.t('foldererror' + data.value.error, { folderName: data.value.path }));
	},
	handleFolderSuccess: function(data) {
		app.view.BaseDialog.prototype.handleFolderSuccess.apply(this, arguments);
		this.$el.modal('hide');
	}
});