app.view.HistoryDialog = app.view.BaseDialog.extend({
	template: 'history-dialog',
	id: 'history-dialog',
	events: {
		'hidden.bs.modal': 'remove',
		'click #downloadDebugLogLink': 'downloadDebugLinkClicked',
	},
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);
		_.bindAll(this, 'scroll');

		this._views = [];
		this._tailindex = -1;
		this._allRendered = false;
	},
	postRender: function() {
		var _this = this;

		this.collection.fetch({
			success: function(collection, response, options) {
				if (collection.length > 0) {
					_this.$el.find('#historyContainer').removeClass('empty');
					_this.$el.find('#history-message').addClass('hidden');
					_this.renderMoreEntries(20);
				} else {
					_this.replaceMessage($.t('nohistory'));
				}

				_this.$el.find('.tableScrollContainer').scroll(_this.scroll);
			}
		});
	},
	scroll: function(e) {
		var pxFromBottom = this.$('.tableScrollContainer').scrollTop() + this.$('.tableScrollContainer').height() - e.target.scrollHeight;
		if (!this._allRendered && pxFromBottom > -300) {
			this.renderMoreEntries(20);
		}
	},
	renderModel: function(entryModel) {
		var view = new app.view.HistoryEntryView({
			model: entryModel
		});
		this._views.push(view);
		this.$el.find('tbody').append(view.render().el);
	},
	downloadDebugLinkClicked: function(ev) {
		window.location.href = '/gui/?token=' + utWebUI.TOKEN + '&action=downloadlog';
	},
	renderMoreEntries: function(length) {
		var startIndex = this._tailindex + 1;
		for (var index = startIndex; index < startIndex + length; index++) {
			this.renderModel(this.collection.at(index));
			this._tailindex = index + 1;

			if (index === this.collection.length -1) {
				this._allRendered = true;
				this.$el.find('.tableScrollContainer').unbind('scroll', this.scroll);
				break;
			}
		}
	},
	replaceMessage: function(msg) {
		this.$el.find('#history-message').text(msg);
	},
	remove: function() {
		this.$el.find('.tableScrollContainer').unbind('scroll', this.scroll);

		while(this._views.length) {
			this._views.pop().remove();
		}

		app.view.BaseDialog.prototype.remove.apply(this, arguments);
	}
});
