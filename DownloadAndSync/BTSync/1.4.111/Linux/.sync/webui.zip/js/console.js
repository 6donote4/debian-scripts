if(!window.console)
	window.console = {};
if(!window.console.log)
	window.console.log = function(){};
if(!window.console.warn)
	window.console.warn = function(){};
if(!window.console.error)
	window.console.error = function(){};