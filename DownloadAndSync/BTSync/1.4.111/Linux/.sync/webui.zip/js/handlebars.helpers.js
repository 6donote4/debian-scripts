Handlebars.registerHelper('myif', function(conditional, value, options) {
	if(conditional == value) {
		return options.fn(this);
	} else {
		return options.inverse(this);
	}
});

Handlebars.registerHelper('myunless', function(conditional, value, options) {
	if(conditional != value) {
		return options.fn(this);
	} else {
		return options.inverse(this);
	}
});

Handlebars.registerHelper('inflectNoun', function(value, single, multiple, options) {
	return app.utils.inflectNoun(value, single, multiple, options);
});

Handlebars.registerHelper('t', function(s, opt) {
	return $.t(s, opt.hash);
});

Handlebars.registerHelper('formatSpeed', function(s) {
	return app.utils.formatSpeed(s);
});

Handlebars.registerHelper('formatDateFromNow', function(d) {
	return moment(d*1000).fromNow();
});

Handlebars.registerHelper('formatDateFromNowMs', function(d, noSuffix) {
	return moment(d).fromNow(noSuffix);
});

Handlebars.registerHelper('formatDateTime', function(d) {
	return moment(d*1000).format('lll');
});

Handlebars.registerHelper('formatDateTimeMs', function(d) {
	return moment(d).format('lll');
});

Handlebars.registerHelper('formatFileSize', function(s) {
	return app.utils.formatFileSize(s);
});

Handlebars.registerHelper('formatFileSizeRounded', function(s) {
	return app.utils.formatFileSize(s, 0, true);
});

Handlebars.registerHelper('concat', function() {
	// concatenate all inputs
	return Array.prototype.slice.call(arguments, 0, -1).join('');
});

Handlebars.registerHelper('renderStatus', function() {
	// determine status column content

	if(!this.statusType)
		return '';

	var html = app.templates['template-status-' + this.statusType](this);

	return new Handlebars.SafeString(html);
});

Handlebars.registerHelper('formatFingerprint', function(f) {
	// assume fingerprint is 40 chars
	var numInserted = 0;
	var insertEvery = 4;
	var insertChars = ['\u30fb', ' '];
	while(true) {
		var insertionPoint = insertEvery * ++numInserted + (numInserted - 1) * insertChars[0].length;
		if(f.length - 1 < insertionPoint)
			break;

		f = f.insert(insertChars[numInserted % 2], insertionPoint);

	}
	return f;
});

Handlebars.registerHelper('doubleEscape', function(s) {
	return new Handlebars.SafeString(Handlebars.Utils.escapeExpression(Handlebars.Utils.escapeExpression(s)));
});