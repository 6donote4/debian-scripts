app.model.DebugMode = app.model.PropertyModel.extend({
	propertyName: 'debugmode'
});