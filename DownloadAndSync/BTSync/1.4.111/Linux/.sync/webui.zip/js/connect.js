app.view.Connect = app.view.BaseDialog.extend({
	template: 'connect-dialog',
	id: 'connect-dialog',
	events: {
		'click #connect-change' : 'changeFolderClicked',
		'click #connect-ok': 'okClicked',
		'click #connect-cancel': 'cancelClicked'
	},

	options: null,

	initialize: function() {
		_.bindAll(this, 'addFolderCallback');
		app.view.Base.prototype.initialize.apply(this, arguments);
	},
	show: function(options) {
		this.$el.modal({
			backdrop: 'static',
			keyboard: false
		});
	},
	changeFolderClicked: function() {
		this.hideError();
		if (app.isDesktop) {
			var path = btsync.showchoosefolderdialog();
			if (path) {
				this.$el.find('#connect-path').val(path + app.DELIMITER + this.options.folderName);
			}
		} else {
			var _this = this;
			_this.close(true);
			app.addFolderView.showToGetFolder(function(path) {
				_this.open();
				if(!path) return;
				_this.$('#connect-path')
				.val(path + app.DELIMITER + _this.options.folderName);
			});
		}
	},
	okClicked: function() {
		this.hideError();
		var _this = this;
		utWebUI.validateUserIdentity(function(val) {
			if (!val) return;

			utWebUI.addLink(_this.options.link, _this.$('#connect-path').val(), _this.addFolderCallback);
		});
	},
	cancelClicked: function() {
		utWebUI.linkAdded(this.options.link, false, 'cancel clicked');
		this.cleanup();
	},
	showError: function(msg) {
		this.$('#connect-error').text(msg);
		this.$('#connect-error-container').removeClass('invisible');
	},
	hideError: function() {
		this.$('#connect-error-container').addClass('invisible');
	},
	handleFolderForceable: function(data) {
		utWebUI.linkAdded(this.options.link, false, 'error' + data.value.error);
		var _this = this;
		var message = $.t('foldererror' + data.value.error, { folderName: _this.$('#connect-path').val() });
		btconfirm(message, function(success) {
			if (success) {
				utWebUI.addForceLink(_this.options.link, _this.$('#connect-path').val(), _this.addFolderCallback);
			}
		});
	},
	handleFolderUnrecoverable: function(data) {
		utWebUI.linkAdded(this.options.link, false, 'error' + data.value.error);
		this.showError($.t('foldererror' + data.value.error, { folderName: this.$("#connect-path").val() }));
	},
	handleFolderSuccess: function(data) {
		app.view.BaseDialog.prototype.handleFolderSuccess.apply(this, arguments);
		app.folders.newFolderLinked = true;
		utWebUI.linkAdded(this.options.link, true);
		this.cleanup();
	},
	cleanup: function() {
		this.$el.one('hidden.bs.modal', _.bind(function() {
			this.remove();
		}, this));
		this.close();
	}
});