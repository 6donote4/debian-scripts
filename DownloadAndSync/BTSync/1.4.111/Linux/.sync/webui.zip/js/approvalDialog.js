app.view.ApprovalDialog = app.view.BaseDialog.extend({
	template: 'approval-dialog',
	id: 'approval-dialog',
	events: {
		'hidden.bs.modal': 'remove',
		'click #approveButton': 'approveClicked',
		'click #denyButton': 'denyClicked'
	},
	initialize: function() {
		app.view.BaseDialog.prototype.initialize.apply(this, arguments);

		// Set Partial Options
		this.options.pageTitle = $.t('accessRequest');
		this.options.name = this.model.get('folderName');
		this.options.has_key = true;
		this.options.secrettype = this.model.get('readwrite') == true ? 1 : 0;
		var fingerprint = this.model.get('user_identity').fingerprint;
		this.options.fingerprint = fingerprint.substring(0, fingerprint.length - 6);
		this.options.accessCode = fingerprint.substring(fingerprint.length - 6)

		var folderSecret = this.model.get('folder');
		var folders = app.folders.filter(function(model) {
			if (folderSecret === model.get('readonlysecret') || model.get('secret') === folderSecret) {
				return true;
			}
		});

		if (folders.length === 1) {
			this.options.path = folders[0].get('path');
		}
	},
	respondToRequest: function(response) {
		var _this = this;
		var status = response ? SyncConstants.SYNC_REQUEST_APPROVED : SyncConstants.SYNC_REQUEST_REJECTED;
		var req = new app.model.RequestStatus;
		req.set({
			secret: this.model.get('folder'),
			fingerprint: this.model.get('user_identity').fingerprint,
			status: status
		});
		req.save({
			success: function(model, response, options) {
				_this.close();
			},
			error: function(model, response, options) {
				_this.close();
			}
		});
	},
	approveClicked: function() {
		this.respondToRequest(true);
		this.dismiss();
	},
	denyClicked: function() {
		this.respondToRequest(false);
		this.dismiss();
	},
	dismiss: function() {
		var collection = this.model.collection;
		collection.remove(this.model);
		collection.fetch();
	}
});

