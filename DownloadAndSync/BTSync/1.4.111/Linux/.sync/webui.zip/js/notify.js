app.notify = function(title, message, type, params) {
	if(!app.isDesktop)
		return;

	if(!type)
		type = SyncConstants.SYNC_NOTIFICATION_DO_NOTHING;

	if(!params)
		params = '';

	btsync.shownotification({
		title: title,
		message: message,
		type: type,
		param: params
	});
}