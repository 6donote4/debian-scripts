app.col.HistoryCollection  = Backbone.Collection.extend({
	model: app.model.HistoryEntry,
	sync: function(method, model, opts) {
		utWebUI.request("action=history&start=0&length=1000", function(data) {
			if (opts.success) {
				opts.success(data.value);
			}
		});
	}
});
