app.utils = {};

app.utils.formatFileSize = function(size, digits, empty) {
	if (_.isNull(digits) || _.isUndefined(digits)) {
		digits = 2;
	}

	var psize, unit;
	if (!size) {
		return empty ? '' : '0 KB';
	}
	if (size < 1024) {
		psize = size;
		unit = 'B';
	} else if (size < 1024 * 1024) {
		psize = size / 1024;
		unit = 'KB';
	} else if (size < 1024 * 1024 * 1024) {
		psize = size / 1024 / 1024;
		unit = 'MB';
	} else {
		psize = size / 1024 / 1024 / 1024;
		unit = 'GB';
	}
	var multiplier = Math.pow(10, digits);
	psize = Math.round(psize * multiplier) / multiplier;
	return "" + psize + " " + unit;
};

app.utils.formatSpeed = function(speed) {
	var pspeed, unit, numDecimals;
	numDecimals = 1;
	if (!speed) {
		return '0 B/s';
	}
	if (speed < 1024) {
		pspeed = speed;
		unit = 'B/s';
	} else if (speed < 1024 * 1024) {
		pspeed = speed / 1024;
		unit = 'KB/s';
	} else if (speed < 1024 * 1024 * 1024) {
		pspeed = speed / 1024 / 1024;
		unit = 'MB/s';
	} else {
		pspeed = speed / 1024 / 1024 / 1024;
		unit = 'GB/s';
	}
	pspeed = parseInt(pspeed * Math.pow(10, numDecimals)) / Math.pow(10, numDecimals);
	return "" + pspeed + " " + unit;
};

app.utils.fixUnicode = function(s) {
	if(_.isUndefined(s)) return s;
	if(_.isNull(s)) return s;
	try {
		return decodeURIComponent(escape(s));
	}
	catch(e) {
		return s;
	}
};

app.utils.getQueryStringObj = function(url) {
	var vars = {},
			hash;
	var index = url.indexOf('?');
	if (index > -1) {
		var hashes = url.slice(index + 1).split('&');
		for (var i = 0; i < hashes.length; i++) {
			hash = hashes[i].split('=');
			vars[hash[0]] = decodeURIComponent(hash[1]);
		}
	}
	return vars;
};

app.utils.inflectNoun = function(value, single, multiple, options) {
	if(value == 1)
		return single;
	return multiple;
};

app.utils.URLDeserialize = function(url) {
	var args, o, obj, p, params, _i, _len;
	args = url.split('?')[1];
	if (!args) {
		return {};
	}
	params = args.split('&');
	obj = {};
	for (_i = 0, _len = params.length; _i < _len; _i++) {
		p = params[_i];
		o = p.split('=');
		if (!o) {
			continue;
		}
		if (o.length === 2) {
			obj[o[0]] = decodeURIComponent(o[1]);
		} else {
			obj[o[0]] = true;
		}
	}
	return obj;
};

app.utils.setURLParams = function(url, obj) {
	var args, base;
	base = url.split('?')[0];
	args = utils.URLDeserialize(url);
	$.extend(args, obj);
	return "" + base + "?" + ($.param(args));
};

app.utils.getURLParam = function(p) {
	try {
		var query = location.hash;
		var params = query.split('#')[1];
		params = params.split('&');
		params = _.object(_.map(params, function(param) {
			return param.split('=');
		}));
		return params[p];
	}
	catch(e) {
		return undefined;
	}
};

app.utils.getScrollBarWidth = function() {
	// Create the measurement node
	var scrollDiv = document.createElement("div");
	scrollDiv.className = "scrollbar-measure";
	scrollDiv.style.width = "100px";
	scrollDiv.style.height = "100px";
	scrollDiv.style.overflow = "scroll";
	scrollDiv.style.position = "absolute";
	scrollDiv.style.top = "-9999px";
	document.body.appendChild(scrollDiv);

	// Get the scrollbar width
	var scrollbarWidth = scrollDiv.offsetWidth - scrollDiv.clientWidth;

	// Delete the DIV
	document.body.removeChild(scrollDiv);

	return scrollbarWidth;
}

// some new specific type of tooltips
$.fn.stuckTooltip = function(opts) {
	opts = _.extend({
		html: true,
		trigger: 'manual'
	}, opts);

	if(!this.length) return false;
	$.fn.tooltip.apply(this, arguments);

	var _this = this;
	this.data('bs.tooltip').tip().addClass('tooltip-stuck')
	.on('click', function() {
		_this.tooltip('hide');
		_this.tooltip('destroy');
	});

	return $.fn.tooltip.call(this, 'show');
};
$.fn.firstRunTooltip = function(opts, firstRunID, cb) {
	this.on('hide.bs.tooltip', function() {
		var data = app.store.get('firstRunTips') || {};
		data[firstRunID] = true;
		app.store.set('firstRunTips', data);
		cb && cb();
	});
	opts = _.extend({
		animation: false
	}, opts);

	return $.fn.stuckTooltip.call(this, opts);;
};

$.fn.styleTooltip = function(opts) {
	if(!this.length) return false;
	$.fn.tooltip.apply(this, arguments);

	if(opts && opts.css) {
		this.data('bs.tooltip').tip().css(opts.css || {});
	}

	return $.fn.tooltip.call(this, opts);
};

$.fn.tooltip.Constructor.prototype.fixPlacement = function() {
  var $tip = this.tip()
  if(!$tip.length) return;
  var actualWidth  = $tip[0].offsetWidth
  var actualHeight = $tip[0].offsetHeight
  var pos = this.getPosition()
  var calculatedOffset = this.getCalculatedOffset('top', pos, actualWidth, actualHeight)

  this.applyPlacement(calculatedOffset, 'top')
  $tip.css('position', 'absolute');
};

// indexOf Polyfill
if (!Array.prototype.indexOf) {
	Array.prototype.indexOf = function(v) {
		return _.indexOf(this, v);
	}
}

String.prototype.insert = function(str, index) {
	return this.slice(0, index) + str + this.slice(index);
};


(function() {
// wrap ajax calls to patch requests to jsbridge when necessary
var baseAJAX = jQuery.ajax;

jQuery.ajax = function(url, opts) {
	if(_.isString(url)) {
		opts = opts || {};
		opts.url = url;
		return jQuery.ajax(opts);
	}

	opts = url;

	// check if call to core
	var isCore = opts.url.match(/^\/gui\//) != null
	// run through jsbridge if on desktop
	if(isCore && app.isDesktop) {
		// create deferred object
		var d = $.Deferred();
		// create new execution flow to prevent freezing ui
		setTimeout(function() {
			try {
				var callObj = {};
				callObj.type = SyncConstants['SYNC_API_TYPE_' + (opts.type || 'GET').toUpperCase()];
				var urlParams = app.utils.URLDeserialize(opts.url);
				callObj.action = urlParams.action;
				delete urlParams.action;
				// delete urlParams.t;
				callObj.params = $.param(urlParams);

				resp = btsync.callapi(callObj);
				try {
					switch(opts.dataType) {
						case 'xml':
							resp = $.parseXML(resp)
							break;
						case 'json':
							resp = $.parseJSON(resp)
							break;
					}
				} catch(e){}

				// console.log('btsync request', opts.url, resp, resp.error ? 'ERROR': '');

				if(resp.error) {
					opts.error && opts.error.call(this, resp);
					return d.reject(resp);
				}
				opts.success && opts.success.call(this, resp);
				d.resolve(resp);
			} catch(e) {
				d.reject(e);
			}
		}, 0);
		return d;
	}
	return baseAJAX.apply(this, arguments);
};
})();
