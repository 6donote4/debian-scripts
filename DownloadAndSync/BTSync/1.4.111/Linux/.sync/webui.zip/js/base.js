window.app = {};
app.view = {};
app.col = {};
app.model = {};


app.view.Base = Backbone.View.extend({
	baseEvents: {
		"dragstart a" : "handleDrag"
	},
	initialize: function(options) {
		_.bindAll(this, 'render', 'deferred_post_render');
		_.extend(
			this.events || {},
			this.baseEvents || {}
		);
		Backbone.View.prototype.initialize.apply(this, arguments);
		this.options = this.options || options || {};
	},
	handleDrag: function() {
		return false;
	},
	render: function() {
		this.preRender();
		this.rendered = true;
		if(this.template){

			this.$el.html(this.callTemplate("template-" + this.template));
		}
		else
			this.$el.empty();
		this.off('render', this.postRender);
		this.on('render', this.postRender);
		this.off('render', this._call_deferred);
		this.on('render', this._call_deferred);

		this.trigger('render');
		return this;
	},
	callTemplate: function(name, options) {
		options = options || {};
		_.extend(
			options,
			this.options,
			(this.model ? this.model.attributes : {}),
			{isDesktop: app.isDesktop}
		);
		return app.templates[name].call(this, options);
	},
	// override
	preRender: function(){},
	postRender: function(){},
	deferred_post_render: function(){},

	_call_deferred: function(){
		_.defer(this.deferred_post_render);
	},
	addFolderCallback: function(data) {
		if ([100,104,105,106].indexOf(data.value.error) != -1) {
			// forceable error
			try {
				this.handleFolderForceable && this.handleFolderForceable(data);
			} catch (e) {}
			return;
		} else if (data.value.error) {
			// unrecoverable error
			try {
				this.handleFolderUnrecoverable && this.handleFolderUnrecoverable(data);
			} catch (e) {}
			return;
		} else {
			// successful
			try {
				this.handleFolderSuccess && this.handleFolderSuccess(data);
			} catch (e) {}
			getFolders();
		}
	},
	handleFolderSuccess: function(data) {
		app.folders.newFolderSecret = data.value.secret;
		app.folders.trigger('userFolderAdded');
		app.store.set('foldersAdded', true);
	},
	handleExternalLink: function(e) {
		if(app.isDesktop) {
			btsync.openurl({url: $(e.currentTarget).attr('href')});
		} else {
			window.open($(e.currentTarget).attr('href'));
		}
		e.preventDefault();
		return false;
	},
	remove: function() {
		Backbone.View.prototype.remove.apply(this, arguments);
		this.trigger('remove');
	}
});


// simple wrapper for the utWebUI.request method
app.model.APIModel = Backbone.Model.extend({
	sync: function(method, model, opts) {
		// ignore method and model
		var req = this.request;
		if(_.isFunction(this.request))
			req = this.request();
		return utWebUI.request(req, opts.success);
	}
});


// any property that has get/set methods with action and value params
app.model.PropertyModel = Backbone.Model.extend({
	propertyName: undefined,
	parse: function(r) {
		if(_.isUndefined(r.value))
			return r;

		// if value is object, return contents, else return value
		if(_.isObject(r.value))
			return r.value;

		return r;
	},
	buildURL: function(method) {
		var request = 'action=';
		if(['create','update'].indexOf(method) != -1) {
			request = request + 'set' + this.propertyName
			 + '&' + $.param(this.toJSON()).replace(/\+/g, '%20');
		}
		else
			request = request + this.propertyName;
		return request;
	},
	sync: function(method, model, opts) {
		var request = this.buildURL(method);
		return utWebUI.request(request, opts);
	}
});


app.view.BaseDialog = app.view.Base.extend({
	className: 'modal fade',
	attributes: {
		tabindex: -1,
		role: 'dialog',
		'aria-hidden': 'true'
	},
	initialize: function() {
		_.bindAll(this, 'handleResize', 'setMaxHeight');
		app.view.Base.prototype.initialize.apply(this, arguments);
	},
	setMaxHeight: function() {
		this.$el.addClass('measuring');

		// Calculate body size
		var topMargin = parseInt(this.$('.modal-dialog').css('margin-top')) || 0;
		var bottomMargin = parseInt(this.$('.modal-dialog').css('margin-bottom')) || 0;
		// var headerHeight = this.$('.modal-header').outerHeight() || 0;
		// var footerHeight = this.$('.modal-footer').outerHeight() || 0;
		// var calculatedHeight = window.innerHeight - topMargin - headerHeight - footerHeight - bottomMargin;

		var scrollContainer = this.$('.modal-scroll-container');
		if(!scrollContainer.length)
			scrollContainer = this.$('.modal-body').addClass('modal-scroll-container');

		// find the height of the scroll area relative to the height of the entire dialog
		var scrollContainerHeight = scrollContainer.outerHeight(true);
		var scrollContainerMargin = scrollContainerHeight - scrollContainer.innerHeight();
		var modalHeight = this.$('.modal-dialog').outerHeight();
		var paddingHeight = modalHeight - scrollContainerHeight;
		var calculatedHeight = window.innerHeight - topMargin - bottomMargin - paddingHeight - scrollContainerMargin;

		this.$el.addClass('modal-scroll');
		scrollContainer.css({
			'max-height': calculatedHeight + 'px'
		});
		this.$el.removeClass('measuring');
	},
	postRender: function() {
		app.view.Base.prototype.postRender.apply(this, arguments);
		this.$el.data('modalClass', this);
	},
	open: function() {
		this.$el.modal('show');
	},
	openScroll: function() {
		this.setMaxHeight();
		$(window).on('resize', this.handleResize);
		this.$el.modal('show');
	},
	handleResize: function(e) {
		if (this._timerID) {
			clearTimeout(this._timerID);
		}

		this._timerID = setTimeout(this.setMaxHeight, 500);
	},
	close: function() {
		this.$el.modal('hide');
	},
	pulse: function() {
		// pulse the dialog twice
		var $el = this.$el;
		var time = 300;
		$el.addClass('pulse');
		setTimeout(function() {
			$el.removeClass('pulse');
			setTimeout(function() {
				$el.addClass('pulse');
				setTimeout(function() {
					$el.removeClass('pulse');
				}, time);
			}, time);
		}, time);
	},
	insert: function() {
		$('body').append(this.render().el);
		return this;
	},
    remove: function() {
    	$(window).off('resize', this.handleResize);
        app.view.Base.prototype.remove.apply(this, arguments);
    }
});

// compile templates
$(function() {
	app.templates = {};
	$('script[type="text/x-handlebars-template"]').each(function(t) {
		html = $(this).html();
		name = $(this).attr('id');
		app.templates[name] = Handlebars.compile(html);
		if(name.split('-')[0] == 'partial')
			Handlebars.registerPartial(name, app.templates[name]);
		$(this).remove();
	});
});